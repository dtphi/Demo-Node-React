define(['utils/pubsub_mixin'], function(PubSubMixin){
  return Object.create(PubSubMixin).init()
})
