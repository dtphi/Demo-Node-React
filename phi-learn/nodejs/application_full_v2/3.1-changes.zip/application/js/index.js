var PlayerJS = PlayerJS || {}
