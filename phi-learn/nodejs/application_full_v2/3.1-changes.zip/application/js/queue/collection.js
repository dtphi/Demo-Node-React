PlayerJS.queue.collection = (function(){
  var tracks = []

  tracks.push({
    id: 1
  , title: 'First track'
  , duration: 7
  })
  tracks.push({
    id: 2
  , title: 'Best track'
  , duration: 12
  })
  tracks.push({
    id: 3
  , title: 'New track'
  , duration: 23
  })

  return tracks
}())
