PlayerJS.player = {}
